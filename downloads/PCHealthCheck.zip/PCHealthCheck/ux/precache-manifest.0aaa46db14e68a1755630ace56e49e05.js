self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "4747180c460a78ae833a8596aa5cf39f",
    "url": "./index.html"
  },
  {
    "revision": "e9a77f49fc7532a6a283",
    "url": "./static/css/main.db68673e.chunk.css"
  },
  {
    "revision": "edd90e6cde5b60c0ffd7",
    "url": "./static/js/2.f4965ae2.chunk.js"
  },
  {
    "revision": "3fc55b82b9dc6557779de2c87a4cda29",
    "url": "./static/js/2.f4965ae2.chunk.js.LICENSE.txt"
  },
  {
    "revision": "e9a77f49fc7532a6a283",
    "url": "./static/js/main.d00e2c05.chunk.js"
  },
  {
    "revision": "430fcbf21b2e4be4e86c",
    "url": "./static/js/runtime-main.34e93b67.js"
  },
  {
    "revision": "4e8f0d66f9a6091343e2557b2ee99e0f",
    "url": "./static/media/backup-Sync.4e8f0d66.svg"
  },
  {
    "revision": "dfd8f5eefdea8140bd579143b292b609",
    "url": "./static/media/fabricmdl2icons-3.54.dfd8f5ee.woff"
  },
  {
    "revision": "e4826bfb9887dc8510b9eaeb88156f68",
    "url": "./static/media/ms-logo.e4826bfb.svg"
  },
  {
    "revision": "28d8f6f7c6b984b14b1ddf772a0d2357",
    "url": "./static/media/pc-health.28d8f6f7.ico"
  },
  {
    "revision": "0c55a4f01d0971f37b32e2e50f82e8e7",
    "url": "./static/media/upgrade-bg.0c55a4f0.jpg"
  },
  {
    "revision": "3ff26f7bf991828032dd4a72cc680d01",
    "url": "./static/media/upgrade-eligible.3ff26f7b.svg"
  },
  {
    "revision": "f8b0d3b534718f7d8a08e61ca43d4eaa",
    "url": "./static/media/upgrade-not-eligible.f8b0d3b5.svg"
  },
  {
    "revision": "a70224990c351750f23634371f8c99ff",
    "url": "./static/media/upgrade-unknown.a7022499.svg"
  },
  {
    "revision": "bbc9278f7f4ea069129bded3f8ae696b",
    "url": "./static/media/win10-laptop.bbc9278f.svg"
  },
  {
    "revision": "e97ff1f54b804bd98d3bf6d5d507eb98",
    "url": "./static/media/windows-update.e97ff1f5.svg"
  },
  {
    "revision": "5a3d9c22ec63ca6728a2db562c1e05d1",
    "url": "./static/media/your-device-desktop.5a3d9c22.png"
  },
  {
    "revision": "9be18575af752058ae68259e032641f8",
    "url": "./static/media/your-device-laptop.9be18575.png"
  },
  {
    "revision": "9a6d3ad237b56323bac20fc701a879c8",
    "url": "./static/media/your-device-tablet.9a6d3ad2.png"
  }
]);